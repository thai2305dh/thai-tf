from flask import Flask, jsonify
import newspaper
from newspaper import Article
import sqlite3
application = Flask(__name__)


APP = Flask(__name__)

# print a nice greeting.
def say_hello(username = "World"):
    return '<p>Hello %s!</p>\n' % username

# some bits of text for the page.
header_text = '''
    <html>\n<head> <title>EB Flask Test</title> </head>\n<body>'''
instructions = '''
    <p><em>Hint</em>: This is a RESTful web service! Append a username
    to the URL (for example: <code>/Thelonious</code>) to say hello to
    someone specific.</p>\n'''
home_link = '<p><a href="/">Back</a></p>\n'
footer_text = '</body>\n</html>'



def get_all(query):
    conn = sqlite3.connect("data/database.db")
    dat = conn.execute(query).fetchall()
    conn.close()

    return dat
@application.route("/category", methods=["GET"])
def get_category():
    rows = ultils.get_all("SELECT * FROM category")
    data = []
    for r in rows:
        data.append({
            "id": r[0],
            "name": r[1],
            "url": r[2]
        })
    return jsonify({"category": data})
@application.route("/news", methods=["GET"])
def get_news():
    # rows = ultils.get_all("SELECT * FROM news")
    rows = get_all("SELECT * FROM news")
    data = []
    for r in rows:
        data.append({
            "id": r[0],
            "subject": r[1],
            "description": r[2],
            "image": r[3],
            "orginal": r[4]
        })
    return  jsonify({"news":data})
    pass
def get_news_id(news_id):
    conn = sqlite3.connect("data/database.db")
    sql = '''
    SELECT N.subject, N.description, N.image, B.orginal, C.name, C.url
    SELECT FROM news N INNER JOIN category C ON N.category_id=C.id
    WHERE N.id=?
    '''
    news = conn.execute(sql, (news_id, )).fetchone()
    conn.close()
    return news

@application.route("/news/<int:news_id>", methods=["GET"])
def get_news_by_id(new_id):
    # r = ultils.get_news_by_id(new_id)
    r = ultils.get_news_id(new_id)
    d = {
        "subject:": r[0],
        "description:": r[1],
        "image:": r[2],
        "or_url:": r[3],
        "category_name": r[4],
        "category_url": r[5]
    }
    return jsonify({"product": d})

@application.route("/news/add", methods=["POST"])
def post_add():
    pass

# add a rule for the index page.
application.add_url_rule('/', 'index', (lambda: header_text +
    say_hello() + instructions + footer_text))

# add a rule when the page is accessed with a name appended to the site
# URL.
application.add_url_rule('/<username>', 'hello', (lambda username:
    header_text + say_hello(username) + home_link + footer_text))
def add_news(conn, url, category_id):
    sql = """
    INSERT INTO news(subject, description, image, orginal, category_id)
    Values(?,?,?,?,?)
    """
    article = Article(url)
    article.download()
    article.parse()

    conn.execute(sql, (article.title, article.text,
                        article.top_image, article.url, category_id))
    conn.commit()
# run the app.
def get_news_url():
    cats = get_all("SELECT * FROM category")
    conn = sqlite3.connect("data/database.db")
    for cat in cats:
        cat_id = cat[0]
        url = cat[2]
        cat_paper = newspaper.build(url)
        for article in cat_paper.articles:
            try:
                print("====", article.url)
                add_news(conn, article.url, cat_id)
            except Exception as ex:
                print("error" + str(ex))
                pass
    conn.close()
if __name__ == "__main__":
    #get_news_url()
    # Setting debug to True enables debug output. This line should be
    # removed before deploying a production app.
    application.debug = True
    application.run()
